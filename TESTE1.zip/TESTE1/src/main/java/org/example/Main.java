package org.example;

import org.example.service.Gerenciamento;

public class Main {
    public static void main(String[] args) {
        new Gerenciamento().iniciar();

        // terminar delete, update e read

    }
}